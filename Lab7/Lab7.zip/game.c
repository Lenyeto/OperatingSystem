

void game_init() {
	
}