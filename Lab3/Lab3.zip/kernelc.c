#include "console.h"

void kmain(){
    console_init();
   
	
	//setpixel(10, 10, COLOR16(255, 255, 255));
    
	drawbox(10, 10, 100, 100, COLOR16(255, 255, 255));
	
    while(1){
    }
}
