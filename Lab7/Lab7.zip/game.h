#pragma once

void game_init();